~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
													Lecture 1 - Start
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
1. Lecture 1
	1.1 Logistics
		1.1.2 Piazza
		1.1.3 Whatsapp
		1.1.4 HackerRank
		1.1.5 Doubts - Videos/Bhaiya
		1.1.7 Parking
		1.1.8 Don't Loiter around
	1.2 Course Details
		1.2.1 Content
		1.2.2 Schedule
	1.3 Installations
		1.3.1 JDK
		1.3.2 Eclipse
	1.4 Sample Programs
		1.4.1 Hello World => Test Installation
		1.4.2 Simple Interest => Test Documentation access
		1.4.3 Largest of three => Test Debug
		1.4.4 Sum to n => Variable map
		1.4.5 Is Prime
		1.4.6 Prime till n
		1.4.7 Reverse a number
		1.4.8 GCD n1, n2
		1.4.9 nth Fib
		1.4.10 All fib <= n
	1.5 Patterns
		1.5.1
			*
			*	*
			*	*	*
			*	*	*	*
			*	*	*	*	*
		1.5.2
			1
			2	3
			4	5	6
			7	8	9	10
		1.5.3
			0
			1		1
			2		3		5
			8		13	21	34
		1.5.4
			1
			1		1
			1		2		1
			1		3		3		1
			1		4		6		4		1
			1		5		10	10	5		1
		1.5.5
			*				*
				*		*
					*
				*		*
			*				*
		1.5.6
			*	*	*		*	*	*
			*	*				*	*
			*						*
			*	*				*	*
			*	*	*		*	*	*
		1.5.7
					*
				*	*	*
			*	*	*	*	*
				*	*	*
					*
		1.5.8
					1
				2	3	2	
			3	4	5	4	3
				2	3	2
					1
	1.6 HackerRank
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
															Lecture 1 - End
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
